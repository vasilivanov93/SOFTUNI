package softunilabs.bindingModels;

import javax.validation.constraints.NotNull;

public class LabBindingModel {
    //TODO: Implement me
}
