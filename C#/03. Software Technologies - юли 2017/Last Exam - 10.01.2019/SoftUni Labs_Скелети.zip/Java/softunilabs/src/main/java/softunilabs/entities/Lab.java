package softunilabs.entities;


import javax.persistence.*;

@Entity
@Table(name = "labs")
public class Lab {
    //TODO: Implement me
}
