package softunilabs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoftUniLabsApplication {
    public static void main(String[] args) {
        SpringApplication.run(SoftUniLabsApplication.class, args);
    }
}
