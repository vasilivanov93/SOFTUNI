﻿using System.ComponentModel.DataAnnotations;

namespace SoftUniLabs.Models
{
    public class Lab
    {      
        //TODO
    }
}
