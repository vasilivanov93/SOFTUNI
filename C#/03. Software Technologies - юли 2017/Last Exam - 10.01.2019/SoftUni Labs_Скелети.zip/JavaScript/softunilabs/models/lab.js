const Sequelize = require('sequelize');

module.exports = function (sequelize) {
    //TODO: Implement me
    return null;
};