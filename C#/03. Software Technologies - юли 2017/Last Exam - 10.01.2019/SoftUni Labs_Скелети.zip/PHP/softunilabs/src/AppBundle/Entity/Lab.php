<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Lab
 *
 * @ORM\Table(name="lab")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\LabRepository")
 */
class Lab
{
	//TODO: Implement me
}

