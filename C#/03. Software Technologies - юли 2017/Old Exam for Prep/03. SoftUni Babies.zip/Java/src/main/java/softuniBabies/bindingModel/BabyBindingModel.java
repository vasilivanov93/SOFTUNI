package softuniBabies.bindingModel;

public class BabyBindingModel {
    // TODO
}
