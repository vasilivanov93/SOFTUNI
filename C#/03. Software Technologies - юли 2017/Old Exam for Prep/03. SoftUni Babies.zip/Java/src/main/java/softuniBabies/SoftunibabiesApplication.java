package softuniBabies;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoftunibabiesApplication {

    public static void main(String[] args) {
        SpringApplication.run(SoftunibabiesApplication.class, args);
    }
}
