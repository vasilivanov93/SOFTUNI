const Baby = require('../models').Baby;

module.exports = {
    index: (req, res) => {
       //TODO
    },

    createGet: (req, res) => {
        //TODO
    },

    createPost: (req, res) => {
        //TODO
    },

    editGet: (req, res) => {
        //TODO
    },

    editPost: (req, res) => {
        //TODO
    },

    deleteGet: (req, res) => {
        //TODO
    },

    deletePost: (req, res) => {
        //TODO
    }
};