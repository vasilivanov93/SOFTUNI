<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Baby
 *
 * @ORM\Table(name="baby")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\BabyRepository")
 */
class Baby
{
    //TODO
}
