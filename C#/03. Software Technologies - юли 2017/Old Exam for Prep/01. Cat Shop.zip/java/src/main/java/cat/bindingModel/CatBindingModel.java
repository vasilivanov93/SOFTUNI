package cat.bindingModel;

public class CatBindingModel {

    // TODO

}
