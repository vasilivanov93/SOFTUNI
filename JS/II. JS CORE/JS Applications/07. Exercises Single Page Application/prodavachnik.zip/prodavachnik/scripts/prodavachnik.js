function startApp() {
    attachEvents();
    showHomeView();
}