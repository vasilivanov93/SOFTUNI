function startApp() {
    showHomeView();
}